import 'package:flutter/material.dart';
import 'screens/home.dart';

void main() {
  runApp(const AIStudentApp());
}

class AIStudentApp extends StatelessWidget {
  const AIStudentApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'AI Student',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF0C1A33)),
        useMaterial3: true,
        fontFamily: 'Roboto',
      ),
      home: const HomeScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}
