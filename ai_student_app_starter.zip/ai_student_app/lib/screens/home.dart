import 'package:flutter/material.dart';
import 'summarize.dart';
import 'solve.dart';
import 'challenges.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('AI Student — مساعد الذكاء للطلاب'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: GridView.count(
          crossAxisCount: 2,
          crossAxisSpacing: 16,
          mainAxisSpacing: 16,
          children: [
            _HomeCard(
              title: 'تلخيص محاضرة',
              subtitle: 'ارفع تسجيل صوتي وسيتم تحويله لملاحظات + أسئلة',
              icon: Icons.graphic_eq,
              onTap: () => Navigator.push(
                context, MaterialPageRoute(builder: (_) => const SummarizeScreen())),
            ),
            _HomeCard(
              title: 'حل مسألة بالصورة',
              subtitle: 'التقط صورة لمسألة وسيتم الشرح خطوة بخطوة',
              icon: Icons.camera_alt,
              onTap: () => Navigator.push(
                context, MaterialPageRoute(builder: (_) => const SolveScreen())),
            ),
            _HomeCard(
              title: 'تحديات يومية',
              subtitle: 'مهمات قصيرة مع نقاط تحفيزية',
              icon: Icons.emoji_events,
              onTap: () => Navigator.push(
                context, MaterialPageRoute(builder: (_) => const ChallengesScreen())),
            ),
            _HomeCard(
              title: 'قريبًا',
              subtitle: 'مزايا قادمة',
              icon: Icons.auto_awesome,
              onTap: () {},
            ),
          ],
        ),
      ),
    );
  }
}

class _HomeCard extends StatelessWidget {
  final String title;
  final String subtitle;
  final IconData icon;
  final VoidCallback onTap;
  const _HomeCard({required this.title, required this.subtitle, required this.icon, required this.onTap, super.key});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          color: Theme.of(context).colorScheme.primaryContainer.withOpacity(.2),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: Theme.of(context).colorScheme.primary.withOpacity(.2)),
        ),
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, size: 40, color: Theme.of(context).colorScheme.primary),
            const SizedBox(height: 12),
            Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
            const SizedBox(height: 6),
            Text(subtitle, style: const TextStyle(fontSize: 12, color: Colors.black54)),
            const Spacer(),
            Align(
              alignment: Alignment.bottomRight,
              child: Icon(Icons.arrow_forward, color: Theme.of(context).colorScheme.primary),
            ),
          ],
        ),
      ),
    );
  }
}
