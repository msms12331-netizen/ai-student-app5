import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../services/ai_service.dart';

class SolveScreen extends StatefulWidget {
  const SolveScreen({super.key});

  @override
  State<SolveScreen> createState() => _SolveScreenState();
}

class _SolveScreenState extends State<SolveScreen> {
  File? imageFile;
  String? answer;
  bool loading = false;

  Future<void> pickImage() async {
    final picker = ImagePicker();
    final picked = await picker.pickImage(source: ImageSource.gallery);
    if (picked != null) setState(() => imageFile = File(picked.path));
  }

  Future<void> solve() async {
    if (imageFile == null) return;
    setState(() { loading = true; answer = null; });
    try {
      final res = await AIService().solveProblem(imageFile!);
      setState(() => answer = res);
    } catch (e) {
      setState(() => answer = 'حدث خطأ: $e');
    } finally {
      setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('حل مسألة بالصورة')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ElevatedButton.icon(
              onPressed: pickImage,
              icon: const Icon(Icons.image),
              label: const Text('اختر صورة للتمرين'),
            ),
            if (imageFile != null) Padding(
              padding: const EdgeInsets.only(top: 8),
              child: Text('تم اختيار: ${imageFile!.path.split('/').last}', style: const TextStyle(fontSize: 12)),
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: loading ? null : solve,
              child: loading ? const CircularProgressIndicator() : const Text('حل مع شرح خطوة بخطوة'),
            ),
            const SizedBox(height: 16),
            Expanded(
              child: SingleChildScrollView(
                child: Text(answer ?? 'النتيجة ستظهر هنا...', style: const TextStyle(fontSize: 14)),
              ),
            )
          ],
        ),
      ),
    );
  }
}
