import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import '../services/ai_service.dart';

class SummarizeScreen extends StatefulWidget {
  const SummarizeScreen({super.key});

  @override
  State<SummarizeScreen> createState() => _SummarizeScreenState();
}

class _SummarizeScreenState extends State<SummarizeScreen> {
  File? audioFile;
  String? result;
  bool loading = false;

  Future<void> pickAudio() async {
    final res = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['mp3','m4a','wav','aac']);
    if (res != null && res.files.single.path != null) {
      setState(() => audioFile = File(res.files.single.path!));
    }
  }

  Future<void> summarize() async {
    if (audioFile == null) return;
    setState(() { loading = true; result = null; });
    try {
      final text = await AIService().summarizeLecture(audioFile!);
      setState(() => result = text);
    } catch (e) {
      setState(() => result = 'حدث خطأ: $e');
    } finally {
      setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('تلخيص محاضرة')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ElevatedButton.icon(
              onPressed: pickAudio,
              icon: const Icon(Icons.upload_file),
              label: const Text('اختر ملف صوتي'),
            ),
            if (audioFile != null) Padding(
              padding: const EdgeInsets.only(top: 8),
              child: Text('تم اختيار: ${audioFile!.path.split('/').last}', style: const TextStyle(fontSize: 12)),
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: loading ? null : summarize,
              child: loading ? const CircularProgressIndicator() : const Text('تلخيص + أسئلة مراجعة'),
            ),
            const SizedBox(height: 16),
            Expanded(
              child: SingleChildScrollView(
                child: Text(result ?? 'النتيجة ستظهر هنا...', style: const TextStyle(fontSize: 14)),
              ),
            )
          ],
        ),
      ),
    );
  }
}
