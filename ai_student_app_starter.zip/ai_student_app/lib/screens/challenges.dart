import 'package:flutter/material.dart';

class ChallengesScreen extends StatefulWidget {
  const ChallengesScreen({super.key});

  @override
  State<ChallengesScreen> createState() => _ChallengesScreenState();
}

class _ChallengesScreenState extends State<ChallengesScreen> {
  int points = 0;
  final List<String> tasks = [
    'راجع درس اليوم لمدة 15 دقيقة',
    'اكتب 3 أسئلة من محاضرة الأمس',
    'حل تمرين واحد في الرياضيات',
    'اقرأ صفحة من ملخصك',
  ];
  final Set<int> done = {};

  void completeTask(int i) {
    if (!done.contains(i)) {
      setState(() {
        done.add(i);
        points += 10;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('تحديات اليوم')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Text('نقاطك: $points', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 16),
            Expanded(
              child: ListView.separated(
                itemCount: tasks.length,
                separatorBuilder: (_, __) => const Divider(),
                itemBuilder: (context, i) {
                  final doneTask = done.contains(i);
                  return ListTile(
                    title: Text(tasks[i]),
                    trailing: Icon(doneTask ? Icons.check_circle : Icons.circle_outlined,
                      color: doneTask ? Colors.green : Colors.grey),
                    onTap: () => completeTask(i),
                  );
                },
              ),
            )
          ],
        ),
      ),
    );
  }
}
