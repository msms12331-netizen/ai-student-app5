# AI Student App (Starter)

A Flutter starter for a student-focused AI app:
- Summarize lecture audio to notes + quiz
- Solve problems by image with step-by-step explanation
- Daily challenges with points

## How to run
1) Install Flutter SDK (stable).
2) In a terminal:
   ```bash
   flutter pub get
   flutter run
   ```

## Where to add your AI
- See `lib/services/ai_service.dart`.
- DO NOT put API keys in the app — proxy through a simple backend.

## Suggested backend
- Tiny Node/Express or Python FastAPI that calls your AI provider.
